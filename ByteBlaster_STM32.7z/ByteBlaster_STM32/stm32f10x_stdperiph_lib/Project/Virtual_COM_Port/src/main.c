/**
  ******************************************************************************
  * @file    main.c
  * @author  MCD Application Team
  * @version V3.4.0
  * @date    29-June-2012
  * @brief   Virtual Com Port Demo main file
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2012 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */


/* Includes ------------------------------------------------------------------*/

#include <stdio.h>
#include <stdarg.h>
#include <stm32f10x.h>

#include "hw_config.h"
#include "usb_lib.h"
#include "usb_desc.h"
#include "usb_pwr.h"

#include "blaster.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Extern variables ----------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/*******************************************************************************
* Function Name  : main.
* Description    : Main routine.
* Input          : None.
* Output         : None.
* Return         : None.
*******************************************************************************/

USART_TypeDef   uart;
USART_InitTypeDef usart_param;
USART_ClockInitTypeDef usart_clock;

uint8_t usb_connstate;
uint8_t CtrlTrfData[8];

uint32_t Fclk, Fns;

uint8_t rom[128] = 
{
0x00, 0x00, 0xFB, 0x09, 0x01, 0x60, 0x00, 0x04, 0x80, 0x28, 0x1C, 0x00, 0x10, 0x01, 0x94, 0x0E,
0xA2, 0x18, 0xBA, 0x12, 0x0E, 0x03, 0x41, 0x00, 0x6C, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00,
0x61, 0x00, 0x18, 0x03, 0x55, 0x00, 0x53, 0x00, 0x42, 0x00, 0x2D, 0x00, 0x42, 0x00, 0x6C, 0x00,
0x61, 0x00, 0x73, 0x00, 0x74, 0x00, 0x65, 0x00, 0x72, 0x00, 0x12, 0x03, 0x30, 0x00, 0x30, 0x00,
0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x30, 0x00, 0x01, 0x02, 0x03, 0x01,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x85, 0xD0
};

void USART_puts(char *data, int n) {
  int8_t c;
  int i;
  for (i = 0; i < n; i++) {
    c = data[i];
    USART_SendData(USART1, (uint8_t)c);
    while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET) {}
  }
}

void uprintf(const char *fmt, ...) {
  va_list args;
  char str[96];
  int n; 
  va_start(args, fmt);
  n = vsprintf(str, fmt, args);
  va_end(args);
  USART_puts(str, n);
  
}


GPIO_InitTypeDef GPIO_InitStructure;

 void gpio_init() {
    
 //GPIO_InitTypeDef GPIO_InitStructure;
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
 RCC_APB2PeriphResetCmd(RCC_APB2Periph_GPIOA, DISABLE);

 RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
 RCC_APB2PeriphResetCmd(RCC_APB2Periph_USART1, DISABLE);
 
 
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_InitStructure.GPIO_Pin = J_TDO | J_ADO;
  GPIO_Init(GPIOA,&GPIO_InitStructure);

 

 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
 RCC_APB2PeriphResetCmd(RCC_APB2Periph_GPIOB, DISABLE);
  
 
 
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Pin = J_TDI | J_TCK | J_TMS | J_NCE | J_NCS | J_OPE | J_SDI;
  GPIO_Init(GPIOB,&GPIO_InitStructure);

    //GPIO_WriteBit(GPIOA,GPIO_Pin_4 ,(State & (1<<0 ))?Bit_RESET:Bit_SET);
  //GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_13)  == Bit_SET
 }

 
 void calibrate_delay() {
    RCC_ClocksTypeDef RCC_Clk;
    RCC_GetClocksFreq(&RCC_Clk);
    Fclk = RCC_Clk.HCLK_Frequency / 1000000;
    Fns = (100 / Fclk) * 10;
 
 }


int main(void)
{
  //int i;
  //uint16_t data;
  
//  GPIO_InitTypeDef GPIO_InitStructure;

  
  Set_System();
  Set_USBClock();
  USB_Interrupts_Config();
  
  /*
  10ms = 100Hz
  
  t = 10ms
  F = 72 Mhz = 72000 Khz
  Ft = 72000 / 16 = 4500 Khz
  C = 4500000 / 100 = 4500
  */
  
  
    
  gpio_init();
  
  RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
  TIM2->PSC = 0xf;
  
  TIM2->ARR = 0xffff;
  TIM2->CNT = 0;
  TIM2->CR1 &= (uint16_t)(~((uint16_t)(TIM_CR1_DIR | TIM_CR1_CMS)));
  TIM2->CR1 |= TIM_CR1_CEN; 
  
  
  while (TIM2->CNT < 22500) {}
  
  
  USART_StructInit(&usart_param);
  usart_param.USART_BaudRate = 9600;
  usart_param.USART_WordLength = USART_WordLength_8b;
  usart_param.USART_StopBits = USART_StopBits_1;
  usart_param.USART_Parity = USART_Parity_No;
  //usart_param.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  //usart_param.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  
  //usart_clock.USART_Clock = USART_Clock_Disable;
  //usart_clock.USART_CPOL = USART_CPOL_Low;
  //usart_clock.USART_CPHA = USART_CPHA_1Edge;
  //usart_clock.USART_LastBit = USART_LastBit_Disable;

  
  //USART_ClockInit(USART1, &usart_clock);
  //USART_Init(USART1, &usart_param);
  //USART_Config_Default();
  //COMInit(USART1, &usart_param);
  
      // Release reset and enable clock
    USART_DeInit(USART1);
    

    // GPIO Init
    // Enable GPIO clock and release reset
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO,
                           ENABLE);
    RCC_APB2PeriphResetCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_AFIO,
                           DISABLE);
    GPIO_PinRemapConfig(GPIO_Remap_USART1,DISABLE);

    // Assign PA9 to UART1 (Tx)
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // Assign PA10 to UART1 (Rx)
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // Init UART1
    USART_Init(USART1,&usart_param);

     USART_Cmd(USART1, ENABLE);

  
  //USART_Init(USART1, &usart_param);
  USB_Init();
  
  calibrate_delay();
  
  uprintf("Hello [CLK = %u Mhz (%u ns)]\n\r", Fclk, Fns);
  //data = 0x3132;
  //for (i = 0; i < 1024; i++) {
  //  USART_SendData(USART1, data);
  //}

  usb_connstate = 0;
 // while (1)
  //{
      main_loop();
  //}
}
#ifdef USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {}
}
#endif

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
