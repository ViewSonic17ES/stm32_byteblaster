#include <stdlib.h>
#include "hw_config.h"
#include "usb_lib.h"
#include "usb_desc.h"
#include "usb_pwr.h"

#include "blaster.h"

#define FIFO_SIZE	256
/*
(100 / 1.33) * 10 ~ 752ns

752 / 3 ~ 251
752 / 4 ~ 188

72Mhz = 13ns

loop = 13 * 6 = 78ns

*/

#define DELAY_NS3       251
#define DELAY_NS4       188



#define         SERIAL_MODE_MASK     0x80
#define         READ_MODE_MASK       0x40
#define         DATA_MASK            0x3f


void *memcpy (void *, const void *, unsigned);
void uprintf(const char *fmt, ...);

uint8_t IsUsbConfigured();


uint8_t OutPacket[64];
uint8_t InPacket[64];
uint8_t InFIFO[FIFO_SIZE];
uint8_t usb_tx_buffer[128];

uint8_t new_data_in, usb_tx_free, usb_tx_size;
extern uint8_t new_data_in_h;

extern uint32_t Fclk, Fns;

unsigned int fifo_wp, fifo_rp;		//FIFO Write Pos / Read Pos
int recv_byte;			//byte count received
uint8_t jtag_byte;			//byte count fot jtag mode
uint8_t aser_byte;			//byte count fot active-serial mode
uint8_t PPB;

uint8_t received;
uint8_t read;

uint8_t bufptr;

uint8_t mode;                           //0 - ASer 1 - JTAG
uint8_t spp_prev;

#define bitcopy(in,out) {if(in) (out)=1; if(!(in)) (out)=0;}
#define bitmask(byte,i) ((byte)&(1<<(i)))




extern uint8_t usb_connstate;
uint8_t USBInHandle0, USBOutHandle0, USBOutHandle1;
uint8_t send_indicator;

uint8_t acc0, acc1;


unsigned int fifo_used() {
  unsigned int n;
  if (fifo_wp == fifo_rp) return 0;
  if (fifo_wp > fifo_rp) n = fifo_wp - fifo_rp; else n = ((FIFO_SIZE - 1) - fifo_rp) + fifo_wp;
  return n;
}


unsigned int fifo_able() {
  return FIFO_SIZE - fifo_used();

}


void enqueue(uint8_t a){
	InFIFO[fifo_wp]=(a);
	if(fifo_wp == (FIFO_SIZE - 1)) fifo_wp = 0; else fifo_wp++;
}


void dequeue(unsigned char *a, unsigned int c){
	unsigned int n;
	
	if (fifo_rp <= (FIFO_SIZE - c)) {
		memcpy((unsigned char*)a, (void*)&InFIFO[fifo_rp], c);
		fifo_rp += c;
		if (fifo_rp == FIFO_SIZE) fifo_rp = 0;

	} else {
		n = FIFO_SIZE - fifo_rp;
		memcpy((unsigned char*)a, (void*)&InFIFO[fifo_rp], n); 
		memcpy((unsigned char*)a + n, (void*)&InFIFO[0], c - n); 
		fifo_rp = c - n;
	}

}





void delay(int ns) {
  volatile int i;
  //i = ns / (6 * Fns);
  i = 4;
  //for (i = 0; i < 16; i++) {
  //}
  while (i-- >0) asm ("nop");
}

void SetOutPort(uint8_t a) {
        uint16_t s, r;
	s = r =  0;
	
	if (a & 0x1) s |= J_TCK; else r |= J_TCK;	//b0

	a = a >> 1;
	if (a & 0x1) s |= J_TMS; else r |= J_TMS;       //b1

	a = a >> 1;
	if (a & 0x1) s |= J_NCE; else r |= J_NCE;       //b2

	a = a >> 1;
	if (a & 0x1) {s |= J_NCS; mode = 1;} else {r |= J_NCS; mode = 0;}       //b3

	a = a >> 1;
	if (a & 0x1) s |= J_TDI; else r |= J_TDI;       //b4


	a = a >> 1;
	if (a & 0x1) s |= J_OPE; else r |= J_OPE;       //b5

	a = a >> 1;
	if (a & 0x1) s |= J_NC; else r |= J_NC;       //b6

	a = a >> 1;
	if (a & 0x1) s |= J_SDI; else r |= J_SDI;       //b7


        GPIO_ResetBits(GPIOB, r);
        //uprintf("GPIO_RST 0x%x\n\r", r);
        GPIO_SetBits(GPIOB, s);
        //uprintf("GPIO_SET 0x%x\n\r", s);
        delay(DELAY_NS4);

}

void JTAG_Write(uint8_t a) {
//      uprintf("JW 0x%x\n\r", a);
      int i;
      uint8_t tdi;
      for (i = 0; i < 8; i++) {
          tdi = a >> i;
          GPIO_WriteBit(GPIOB, J_TDI ,(tdi & 0x1)?Bit_SET:Bit_RESET);
          delay(DELAY_NS4);
          GPIO_WriteBit(GPIOB, J_TCK, Bit_SET);
          delay(DELAY_NS4);
          GPIO_WriteBit(GPIOB, J_TCK, Bit_RESET);
          delay(DELAY_NS4);
          
      }

}


uint8_t JTAG_RW(uint8_t a) {
  int i;
  uint8_t tdi, ret = 0;

  for (i = 0; i < 8; i++) {
          tdi = a >> i;
          GPIO_WriteBit(GPIOB, J_TDI ,(tdi & 0x1)?Bit_SET:Bit_RESET);
          delay(DELAY_NS4);
          if (GPIO_ReadInputDataBit(GPIOA, J_TDO) == Bit_SET) ret |= (1 << i);
          delay(DELAY_NS4);
          GPIO_WriteBit(GPIOB, J_TCK, Bit_SET);
          delay(DELAY_NS4);
          GPIO_WriteBit(GPIOB, J_TCK, Bit_RESET);
          delay(DELAY_NS4);
  }

//  uprintf("JRW 0x%x <- 0x%x\n\r", ret, a);
  
  
  return ret;

}

uint8_t ASer_RW(uint8_t a) {
  int i;
  uint8_t tdi, ret = 0;
  //uprintf("ARW 0x%x\n\r", a);
  for (i = 0; i < 8; i++) {
          tdi = a >> i;
          GPIO_WriteBit(GPIOB, J_TDI ,(tdi & 0x1)?Bit_SET:Bit_RESET);
          delay(DELAY_NS4);
          if (GPIO_ReadInputDataBit(GPIOA, J_ADO) == Bit_SET) ret |= (1 << i);
          delay(DELAY_NS4);
          GPIO_WriteBit(GPIOB, J_TCK, Bit_SET);
          delay(DELAY_NS4);
          GPIO_WriteBit(GPIOB, J_TCK, Bit_RESET);
          delay(DELAY_NS4);
  }
	  return ret;

}



//uint8_t USBHandleBusy(uint8_t handle) {
//  if (received == 1) return 0; else return 1;
//}

void mUSBTxOnePacket(uint8_t handle, uint8_t a, uint8_t *data, int size) {
      usb_tx_free = 0;
      //UserToPMABufferCopy(data, ENDP1_TXADDR, size);
        USB_SIL_Write(EP1_IN, data, size);
      //SetEPTxCount(ENDP1, size);
      SetEPTxValid(ENDP1); 
      
  
 //     memcpy(&usb_tx_buffer[0], data, size);
   //   usb_tx_size = size;
     // usb_tx_free = 0;
      

}

int USBHandleGetLength(uint8_t handle) {
      return  GetEPRxCount(EP2_OUT & 0x7F);

}

void mUSBRxOnePacket(uint8_t handle, uint8_t a, uint8_t *data, int size) {
  new_data_in_h = 0;      
  //USART_SendData(USART1, 0x6262);  
  PMAToUserBufferCopy(data, GetEPRxAddr(EP2_OUT & 0x7F), size);
  //SetEPRxCount(ENDP2, 0);
  SetEPRxValid(ENDP2);
  new_data_in = 0;      
  
}






uint8_t tx_free() {
  if (usb_tx_free) {
        //if (!GetEPTxCount(ENDP1)) 
        return 1;
  } 
  return 0;
}



void tx_to_host() {
      if (tx_free()) {
                                acc0=fifo_used();
                                //uprintf("tx_to_host 0x%x\n\r", acc0);
				if(acc0 >= 62){		//send filled packet to host
					dequeue(&InPacket[2],62);
				//	uprintf("acc0 > 62 0x%x\n\r", GetEPTxCount(ENDP1));
                                        mUSBTxOnePacket(USBInHandle0,1,&InPacket[0],2+62);
                                        send_indicator = 1;       
				}else if(acc0){			//send non-filled packet to host
				//	uprintf("acc0!\n\r");
                          //               uprintf("acc0 > 0x%x \n\r", GetEPTxCount(ENDP1));
                                         dequeue(&InPacket[2],acc0);
					mUSBTxOnePacket(USBInHandle0,1,&InPacket[0],2+acc0);
                                        send_indicator = 1;
                                 }else if((send_indicator) || (TIM2->CNT >= 4500)){	//send packet indicator                       
                                       mUSBTxOnePacket(USBInHandle0,1,&InPacket[0], 2);
                                        send_indicator = 0;                                                                            
                                        TIM2->CNT = 0;
				}
    }
}


void check_new_data() {
	if(!recv_byte){
		if(new_data_in_h){
//                          uprintf("rcv\n\r");
                        recv_byte=USBHandleGetLength(USBOutHandle0);
			bufptr=0;
			received=1;
		}
	}
}



void rx_new_data() {
	if(received && (!new_data_in) ){
				//LACT=1;
				mUSBRxOnePacket(USBOutHandle0,2,&OutPacket[0],64);
				received=0;
				new_data_in = 1;
	}
}





int usbconn_wait() {
  if (usb_connstate) return 0;
  return 1;
}


void USBCBInitEP(){
//    USBEnableEndpoint(1,USB_IN_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
  //  USBEnableEndpoint(2,USB_OUT_ENABLED|USB_HANDSHAKE_ENABLED|USB_DISALLOW_SETUP);
	USBOutHandle0=0;
	USBOutHandle1=0;
	USBInHandle0=0;
	fifo_wp=0;
	fifo_rp=0;
	recv_byte=0;
    jtag_byte=0;
    aser_byte=0;
    PPB = 0;
    received = 0;
    read = 0;
    mode = 1;
    spp_prev = 0;
    new_data_in_h = 0;
    new_data_in = 0;
    usb_tx_free = 1;
    SetOutPort(0x1E);
    
    
     SetEPTxCount(ENDP1, 0);
     SetEPTxValid(ENDP1); 
}


void process_data() {
	if(recv_byte && new_data_in){
                              //uprintf("process\n\r");
                              //LACT=0;
				new_data_in = 0;
				do{
					if(jtag_byte){
						#ifdef USE_SPI
						ChangeSPI();
						acc0=bitreverse[OutPacket[0][bufptr++]];
						#endif
						if(!read){
							do{
								#ifdef USE_SPI
								SSPBUF=acc0;
								acc0=bitreverse[OutPacket[0][bufptr++]];
								SPI_Wait();
								#else
								acc0=OutPacket[bufptr++];
								JTAG_Write(acc0);
								#endif
								jtag_byte--;
								recv_byte--;
							}while(jtag_byte&&recv_byte);
						}else{
							do{
								#ifdef USE_SPI
								SSPBUF=acc0;
								acc0=bitreverse[OutPacket[0][bufptr++]];
								SPI_Wait();
								acc1=bitreverse[SSPBUF];
								enqueue(acc1);
								#else
								acc0=OutPacket[bufptr++];
								acc1 = JTAG_RW(acc0);
//								JTAG_RW(acc0, acc1);
								//usart_outc(acc1, 1);
								enqueue(acc1);
								#endif
								jtag_byte--;
								recv_byte--;
							}while(jtag_byte&&recv_byte);
						}
						#ifdef USE_SPI
						bufptr--;
						ChangePIO();
						#endif
					}else if(aser_byte){
						if(!read){
							#ifdef USE_SPI
							ChangeSPI();
							acc0=bitreverse[OutPacket[0][bufptr++]];
							#endif
							do{
								#ifdef USE_SPI
								SSPBUF=acc0;
								acc0=bitreverse[OutPacket[0][bufptr++]];
								SPI_Wait();
								#else
								acc0=OutPacket[bufptr++];
								JTAG_Write(acc0);
								#endif
								aser_byte--;
								recv_byte--;
							}while(aser_byte&&recv_byte);
							#ifdef USE_SPI
							bufptr--;
							ChangePIO();
							#endif
						}else{
							do{
								acc0=OutPacket[bufptr++];
//								acc1 = ASer_RW(acc0);
								enqueue(acc1);
								aser_byte--;
								recv_byte--;
							}while(aser_byte&&recv_byte);
						}
					}else{
						do{
							acc0=OutPacket[bufptr++];
							bitcopy(bitmask(acc0,6),read);
							if(bitmask(acc0,7)){		//EnterSerialMode
							  GPIO_WriteBit(GPIOB, J_TCK, Bit_RESET);	
                                                          //LTCK=0;		//bug fix
								if(mode){	//nCS=1:JTAG
									jtag_byte=acc0&0x3F;
								}else{		//nCS=0:ActiveSerial
									aser_byte=acc0&0x3F;
								}
								recv_byte--;
								break;
							}else{			//BitBangMode
								//OUTP=acc0;
                                                                SetOutPort(acc0);
								if(read){
									acc1=0;
									if (GPIO_ReadInputDataBit(GPIOA, J_ADO) == Bit_SET) acc1|=0x02;
                                                                        if (GPIO_ReadInputDataBit(GPIOA, J_TDO) == Bit_SET) acc1|=0x01;									
                                                                        //if(PADO) acc1|=0x02;
						 			//if(PTDO) acc1|=0x01;
									enqueue(acc1);
								}
								recv_byte--;
							}
						}while(recv_byte);
					}
				}while(recv_byte);
			}
}



void main_loop() {
    USBCBInitEP();
    send_indicator = 0;
    InPacket[0]=0x31;
    InPacket[1]=0x60;

    while(1) {
        
      if (IsUsbConfigured()) continue;
        tx_to_host();
        check_new_data();
        if(fifo_able() < recv_byte) continue;	        
        rx_new_data();		
        process_data();
    
        
    
    }

}