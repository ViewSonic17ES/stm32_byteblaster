#define J_TCK  GPIO_Pin_0
#define J_TMS  GPIO_Pin_1
#define J_NCE  GPIO_Pin_2
#define J_NCS  GPIO_Pin_3
#define J_TDI  GPIO_Pin_6
#define J_OPE  GPIO_Pin_5
#define J_NC  GPIO_Pin_4
#define J_SDI  GPIO_Pin_7


#define J_TDO  GPIO_Pin_4
#define J_ADO  GPIO_Pin_5

void main_loop();

